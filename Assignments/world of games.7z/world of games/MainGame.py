from Live import welcome, load_game

print(welcome('Guy'))
load_game()